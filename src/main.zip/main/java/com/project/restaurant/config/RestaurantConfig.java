package com.project.restaurant.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;

@Configuration
public class RestaurantConfig {

    //使用JSON的序列化方式来序列化对象数据到redis中（方便读取与存储）
    public RedisSerializer<Object> redisSerializer(){
        return new GenericJackson2JsonRedisSerializer();
    }


}
