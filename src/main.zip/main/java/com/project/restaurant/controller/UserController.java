package com.project.restaurant.controller;


import com.project.restaurant.R;
import com.project.restaurant.constant.MemberConstant;
import com.project.restaurant.service.UserService;
import com.project.restaurant.vo.MemberInfoVo;
import com.project.restaurant.vo.SignUpVo;
import com.project.restaurant.vo.UserLoginVo;
import com.project.restaurant.vo.UserRegistVo;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.*;
import java.util.concurrent.TimeUnit;

@RestController
public class UserController {

    public static final String LOGIN_USER = "loginUser";
    public static final String RESTAURANT_SESSION_ID = "restaurantSessionID";

    @Resource
    UserService userService;
    @Resource
    StringRedisTemplate stringRedisTemplate;

    @PostMapping("/login")
    public R userLogin(@RequestBody UserLoginVo vo, HttpServletRequest request,
                       HttpSession session) {
//        System.out.println(vo.toString());
//        System.out.println(session);

        MemberInfoVo memberInfoVo = userService.loginRequest(vo);

        if(memberInfoVo==null){
            return R.error("Account Not Exists");
        }

        String uuid = UUID.randomUUID().toString().replace("-", "");
        memberInfoVo.setToken(uuid);
        stringRedisTemplate.opsForValue().set(MemberConstant.LOGIN_USER+uuid,memberInfoVo.toString(),1440,TimeUnit.MINUTES);
        session.setAttribute(LOGIN_USER, memberInfoVo);   //set session

        return R.ok().setData(memberInfoVo);
    }

    /**
     * Member Registration
     * @param signUpVo
     * @param result
     * @return
     */
    @PostMapping("/signUp")
    public R userLogin2(@Valid @RequestBody SignUpVo signUpVo, BindingResult result ) {

        if (result.hasErrors()) {
            Map<String, String> error = new HashMap<>();
            List<FieldError> fieldErrors = result.getFieldErrors();
            for (FieldError fieldError : fieldErrors) {
                if (!error.containsKey(fieldError.getField())) {
                    error.put(fieldError.getField(), fieldError.getDefaultMessage());
                }
            }
            return R.error().setData(error);
        }

        UserRegistVo userRegistVo = new UserRegistVo(signUpVo.getUserName(), signUpVo.getPasswords());
        MemberInfoVo memberInfoVo = new MemberInfoVo(signUpVo.getFirstName(), signUpVo.getLastName(), signUpVo.getPhoneNumber(), signUpVo.getEmail());
        R r = new R();
        try {
           r = userService.signUp(userRegistVo, memberInfoVo);
        } catch (Exception e) {

            return r.error(501,"Unknown");
        }
        return r;
    }

    @GetMapping("/")
    public String userLogin3() {
        return "Hello";
    }


}
