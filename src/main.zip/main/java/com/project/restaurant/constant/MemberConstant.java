package com.project.restaurant.constant;

public class MemberConstant {

    public static final String LOGIN_USER = "loginUser";
    public static final String USER_ORDER = "userOrder";

}
