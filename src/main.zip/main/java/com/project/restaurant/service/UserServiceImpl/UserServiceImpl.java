package com.project.restaurant.service.UserServiceImpl;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.project.restaurant.R;
import com.project.restaurant.dao.MemberDao;
import com.project.restaurant.dao.UserDao;
import com.project.restaurant.service.UserService;
import com.project.restaurant.vo.MemberInfoVo;
import com.project.restaurant.vo.UserLoginVo;
import com.project.restaurant.vo.UserRegistVo;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.annotation.Resource;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

@Service
public class UserServiceImpl extends ServiceImpl<UserDao, UserRegistVo> implements UserService {

    @Resource
    MemberDao memberDao;
    @Resource
    UserDao userDao;

    /**
     * Update new User infomation
     *
     * @param vo
     * @param mvo
     * @return
     * @throws Exception When MySql's insertion failure
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public synchronized R signUp(UserRegistVo vo, MemberInfoVo mvo) throws Exception {

        Integer mobile = baseMapper.selectCount(new QueryWrapper<UserRegistVo>().eq("user_name", vo.getUserName()));

        if (mobile != 0) {
            return R.error("User Name Exists already");
        }

        int result;
        memberDao.insert(mvo);
        result = memberDao.getMaxID();
        if (result == 0) {
            throw new Exception();
        }
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encode = passwordEncoder.encode(vo.getPasswords());
        vo.setMemberId(result);
        vo.setPasswords(encode);

        result = userDao.insert(vo);
        if (result == 0) {
            throw new Exception();
        }
        return R.ok();

    }

    @Override
    public MemberInfoVo loginRequest(UserLoginVo vo) {

        UserRegistVo userRegistVo = baseMapper.selectOne(new QueryWrapper<UserRegistVo>().eq("username", vo.getUserName()));
        if (userRegistVo == null) {
            return null;
        } else {
            String password1 = userRegistVo.getPasswords();
            BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

            if (bCryptPasswordEncoder.matches(vo.getPasswords(), password1)) {
                MemberInfoVo memberInfoVo = memberDao.selectById(userRegistVo.getMemberId());
                if (memberInfoVo != null) {
                    return memberInfoVo;
                }

            }
        }


        return null;
    }
}
