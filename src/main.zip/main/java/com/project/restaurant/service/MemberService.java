package com.project.restaurant.service;

public interface MemberService {
}
